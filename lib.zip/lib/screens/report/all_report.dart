// lib/screens/report/all_report.dart
import 'package:flutter/material.dart';
import 'package:watch_team/session_data.dart';
import 'package:watch_team/services/api_client.dart';
import 'package:watch_team/screens/report/report_detail_screen.dart';

class AllReports extends StatefulWidget {
  const AllReports({super.key});

  @override
  State<AllReports> createState() => _AllReportsState();
}

class _AllReportsState extends State<AllReports> with SingleTickerProviderStateMixin {
  late final ApiClient api;
  late final TabController _tabController;

  late final String myUserId;

  bool loading = true;
  List<Map<String, dynamic>> allReports = [];
  List<Map<String, dynamic>> myReports = [];

  @override
  void initState() {
    super.initState();

    api = ApiClient(baseUrl: 'http://192.168.32.39:9000');

    final profile = SessionData.userProfile ?? <String, dynamic>{};
    myUserId = (profile['_id'] ?? profile['id'] ?? '').toString();

    _tabController = TabController(length: 2, vsync: this);
    loadReports();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> loadReports({String q = ''}) async {
    setState(() => loading = true);
    try {
      // All
      allReports = await api.listReports(q: q, scope: 'all');

      // My
      myReports = myUserId.isEmpty
          ? <Map<String, dynamic>>[]
          : await api.listReports(q: q, scope: 'my', userId: myUserId);

      setState(() {});
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load reports: $e')),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: const Color(0xFF0B0B0B),
        appBar: AppBar(
          backgroundColor: const Color(0xFF0B0B0B),
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.maybePop(context),
          ),
          centerTitle: true,
          title: const Text(
            'Reports',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: 18,
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh, color: Colors.white),
              onPressed: () => loadReports(),
            ),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(64),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: _TabsPill(controller: _tabController),
            ),
          ),
        ),

        body: TabBarView(
          controller: _tabController,
          children: [
            // All Reports
            _ReportsList(
              loading: loading,
              items: allReports,
              onTapItem: (id, title) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ReportDetailScreen(
                      reportId: id,
                      title: title,
                      api: api,
                    ),
                  ),
                );
              },
              onRefresh: () => loadReports(),
            ),

            // My Reports
            _ReportsList(
              loading: loading,
              items: myReports,
              onTapItem: (id, title) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ReportDetailScreen(reportId: id, title: title, api: api),
                  ),
                );
              },
              onRefresh: () => loadReports(),
            ),
          ],
        ),

        bottomNavigationBar: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
          child: SizedBox(
            height: 52,
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context, rootNavigator: true).pushNamed('/select_report');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F3DFF),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                elevation: 0,
              ),
              child: const Text(
                'Add Report',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _TabsPill extends StatelessWidget {
  final TabController controller;
  const _TabsPill({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 44,
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: const Color(0xFF171717),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: TabBar(
        controller: controller,
        dividerColor: Colors.transparent,
        indicatorSize: TabBarIndicatorSize.tab,
        indicator: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(8),
        ),
        labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        labelColor: const Color(0xFFFF4D4D),
        unselectedLabelColor: Colors.white,
        tabs: const [
          Tab(text: 'All Reports'),
          Tab(text: 'My Reports'),
        ],
      ),
    );
  }
}

class _ReportsList extends StatelessWidget {
  final bool loading;
  final List<Map<String, dynamic>> items;
  final void Function(String id, String title) onTapItem;
  final Future<void> Function() onRefresh;

  const _ReportsList({
    required this.loading,
    required this.items,
    required this.onTapItem,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (items.isEmpty) {
      return const _EmptyReportsState(
        title: 'No Report Available',
        useAssetImage: false,
        imageAssetPath: 'assets/report_empty.png',
      );
    }

    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final r = items[index];
          final id = (r['_id'] ?? '').toString();
          final title = (r['title'] ?? '').toString();
          final createdAt = (r['createdAt'] ?? '').toString();

          final attachments = (r['attachments'] is List) ? (r['attachments'] as List) : const [];
          final attachCount = attachments.length;

          final badge = _badgeForTitle(title);

          return InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => onTapItem(id, title),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFF2B2F35),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFF3A3A3A)),
              ),
              child: Row(
                children: [
                  // badge
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: badge.color.withOpacity(0.18),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: badge.color),
                    ),
                    child: Text(
                      badge.text,
                      style: TextStyle(color: badge.color, fontWeight: FontWeight.w800, fontSize: 12),
                    ),
                  ),

                  const SizedBox(width: 12),

                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text(
                          _formatDateTime(createdAt),
                          style: TextStyle(color: Colors.white.withOpacity(0.65), fontSize: 12),
                        ),
                      ],
                    ),
                  ),

                  if (attachCount > 0) ...[
                    const SizedBox(width: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.35),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: const Color(0xFF3A3A3A)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.attach_file, color: Colors.white70, size: 16),
                          const SizedBox(width: 4),
                          Text('$attachCount', style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ],

                  const SizedBox(width: 8),
                  const Icon(Icons.chevron_right, color: Colors.white54),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _Badge {
  final String text;
  final Color color;
  const _Badge(this.text, this.color);
}

_Badge _badgeForTitle(String title) {
  final t = title.toLowerCase();
  if (t.contains('break')) return const _Badge('SECURITY', Color(0xFFFF3D00));
  if (t.contains('incident')) return const _Badge('INCIDENT', Color(0xFF00C853));
  if (t.contains('patrol')) return const _Badge('PATROL', Color(0xFF2962FF));
  if (t.contains('visitor')) return const _Badge('VISITOR', Color(0xFFFFD600));
  return const _Badge('GENERAL', Color(0xFF9E9E9E));
}

String _formatDateTime(String iso) {
  final dt = DateTime.tryParse(iso)?.toLocal();
  if (dt == null) return '';
  final dd = dt.day.toString().padLeft(2, '0');
  final mm = dt.month.toString().padLeft(2, '0');
  final hh = dt.hour.toString().padLeft(2, '0');
  final mi = dt.minute.toString().padLeft(2, '0');
  return '$dd/$mm/${dt.year}  $hh:$mi';
}

class _EmptyReportsState extends StatelessWidget {
  final String title;
  final String imageAssetPath;
  final bool useAssetImage;

  const _EmptyReportsState({
    required this.title,
    required this.imageAssetPath,
    required this.useAssetImage,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF0B0B0B), Color(0xFF070707)],
        ),
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 140,
                height: 140,
                child: useAssetImage
                    ? Image.asset(imageAssetPath, fit: BoxFit.contain)
                    : const _PlaceholderEmptyIllustration(),
              ),
              const SizedBox(height: 14),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PlaceholderEmptyIllustration extends StatelessWidget {
  const _PlaceholderEmptyIllustration();

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Icon(Icons.folder_copy_outlined, size: 110, color: Colors.white.withOpacity(0.20)),
        Positioned(
          bottom: 26,
          child: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0xFF3A3A3A)),
            ),
            child: const Icon(Icons.close, color: Color(0xFFFF4D4D), size: 22),
          ),
        ),
      ],
    );
  }
}

/// --------------------
/// Details Screen
/// --------------------
class ReportDetailScreen extends StatefulWidget {
  final String reportId;
  final String title;
  final ApiClient api;

  const ReportDetailScreen({
    super.key,
    required this.reportId,
    required this.title,
    required this.api,
  });

  @override
  State<ReportDetailScreen> createState() => _ReportDetailScreenState();
}

class _ReportDetailScreenState extends State<ReportDetailScreen> {
  bool loading = true;
  Map<String, dynamic>? report;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final r = await widget.api.getReportById(widget.reportId);
      setState(() => report = r);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed: $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B0B0B),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B0B0B),
        title: Text(widget.title, style: const TextStyle(color: Colors.white)),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : (report == null)
          ? const Center(child: Text('No data', style: TextStyle(color: Colors.white)))
          : _buildBody(),
    );
  }

  Widget _buildBody() {
    final fields =
    (report!['fields'] is Map) ? Map<String, dynamic>.from(report!['fields']) : <String, dynamic>{};
    final attachments =
    (report!['attachments'] is List) ? List<Map<String, dynamic>>.from(report!['attachments']) : <Map<String, dynamic>>[];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Fields', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),

          ...fields.entries.map((e) {
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF2B2F35),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF3A3A3A)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 3,
                    child: Text(
                      e.key,
                      style: TextStyle(color: Colors.white.withOpacity(0.7), fontWeight: FontWeight.w700),
                    ),
                  ),
                  Expanded(
                    flex: 5,
                    child: Text('${e.value}', style: const TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            );
          }),

          const SizedBox(height: 16),
          const Text('Attachments', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),

          if (attachments.isEmpty)
            Text('No attachments', style: TextStyle(color: Colors.white.withOpacity(0.6))),

          ...attachments.map((a) {
            final kind = (a['kind'] ?? '').toString();
            final url = (a['secureUrl'] ?? '').toString();
            final resourceType = (a['resourceType'] ?? '').toString();

            if (url.isEmpty) return const SizedBox.shrink();

            if (resourceType == 'image') {
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFF2B2F35),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF3A3A3A)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Text(
                        kind.toUpperCase(),
                        style: TextStyle(color: Colors.white.withOpacity(0.7), fontWeight: FontWeight.w800),
                      ),
                    ),
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(bottom: Radius.circular(12)),
                      child: Image.network(url, fit: BoxFit.cover),
                    ),
                  ],
                ),
              );
            }

            // Cloudinary stores audio as resourceType=video too (normal)
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF2B2F35),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF3A3A3A)),
              ),
              child: Row(
                children: [
                  Icon(kind == 'audio' ? Icons.audiotrack : Icons.videocam, color: Colors.white70),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      url,
                      style: TextStyle(color: Colors.white.withOpacity(0.8)),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}
